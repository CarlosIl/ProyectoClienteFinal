<?php
function retornarConexion() {
  $con=mysqli_connect("localhost","cigg","toor","supermercado");
  return $con;
}
?>