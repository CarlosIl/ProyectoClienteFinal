
DROP DATABASE IF EXISTS supermercado;
CREATE DATABASE supermercado CHARACTER SET utf8mb4;
USE supermercado;

CREATE TABLE clientes (
  id int(3) PRIMARY KEY auto_increment,
  nombre varchar(50) NOT NULL,
  passwd varchar(50) NOT NULL,
  edad int NOT NULL,
  email varchar(40) DEFAULT NULL,
  sub varchar(20) NOT NULL 
);

CREATE TABLE subscripcion (
	id_sub int(3) PRIMARY KEY,
    tipo varchar(50) NULL
);

INSERT INTO subscripcion (id_sub,tipo) VALUES
(1,"NO"),(2,"BÁSICO"),(3,"INTERMEDIO"),(4,"PREMIUM");